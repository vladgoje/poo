#include "Ui.h"
#include "Validator.h"
#include <iostream>
#include <fstream>

using std::cout;
using std::cin;
using std::string;

void UI::adauga_ui() {
	string name, prod, subst, price;
	cout << "\nNume: "; cin >> name; cout << "Producator: "; cin >> prod; cout << "Substanta activa: "; cin >> subst; cout << "Pret: "; cin >> price;
	srv.adauga(name, prod, subst, price);
	cout << "\nMedicament adaugat cu succes!\n";
}

void UI::printAll_ui() {
	const vector<Medicament> all = srv.getAll();
	cout << "\nLista Medicamente:\n";
	for(const auto& med : all){	
		cout << med;
	}
}

void UI::modifica_ui() {
	printAll_ui();
	string _name, name, prod, subst, price;
	cout << "\nNume medicament de modificat: "; cin >> _name;
	cout << "Nume: "; cin >> name; cout << "Producator: "; cin >> prod; cout << "Substanta activa: "; cin >> subst; cout << "Pret: "; cin >> price;
	srv.modifica(_name, name, prod, subst, price);
	cout << "\nMedicament modificat cu success!\n";
}

void UI::sterge_ui() {
	string _name;
	printAll_ui();
	cout << "\nNume medicament: "; cin >> _name;
	srv.sterge(_name);
	cout << "\nMedicamentul a fost sters cu succes!\n";
}

void UI::cauta_ui() {
	string name;
	cout << "\nNume medicament: "; cin >> name;
	const Medicament& med = srv.cauta(name);
	cout << med;
}

void UI::filtreaza_ui() {
	string type, filter1, filter2;
	cout << "\n1. Filtreaza dupa substanta activa\n";
	cout << "2. Filtreaza dupa pret\n";
	cout << "Tip filtrare: "; cin >> type;
	
	if (type == "2") {
		cout << "Pret minim: "; cin >> filter1;
		cout << "Pret maxim: "; cin >> filter2;
	}
	else
	{
		cout << "Filtru: "; cin >> filter1;
	}

	vector<Medicament> filtered = srv.filtreaza(type, filter1, filter2);

	cout << "\nMedicamente filtrate:\n";
	for (const auto& med : filtered)
		cout << med;
}

void UI::sorteaza_ui() {
	string type;
	cout << "\n1. Sorteaza dupa nume\n";
	cout << "2. Sorteaza dupa producator\n";
	cout << "3. Sorteaza dupa substanta activa + pret\n";
	cout << "Tip sortare: "; cin >> type;

	vector<Medicament> sorted = srv.sorteaza(type);
	cout << "\nMedicamente sortate:\n";
	for (const auto& med : sorted)
		cout << med;
}

void UI::stats_ui() {
	vector<StatsDTO> stats = srv.stats();
	cout << "Stats:\n";
	for(auto& stat : stats)
		cout << stat.getTip() << " -> " << stat.getNr()<<" %\n";
}

void UI::clearRecipe_ui() {
	srv.clearRecipe();
	cout << "\nMedicamentele de pe reteta s-au sters!\n";
	cout << "Medicamente pe reteta: " << srv.getRecipeSize() << '\n';
}

void UI::addOnRecipe_ui() {
	string name;
	cout << "\nNume medicament: "; cin >> name;
	srv.addOnRecipe(name);
	cout << "Medicament adaugat cu succes!\n";
	cout << "Medicamente pe reteta: " << srv.getRecipeSize() << '\n';
}

void UI::generateRecipe_ui() {
	string nr;
	cout << "\nNumar medicamente: "; cin >> nr;
	srv.generateRecipe(nr);
	cout << "Reteta generata!\n";
	cout << "Medicamente pe reteta: " << srv.getRecipeSize() << '\n';
}

void UI::export_ui() {
	string fname;
	cout << "\nNume fisier CSV pentru export: "; cin >> fname;
	srv.exportRecipe(fname);
	cout << "Export success\n";
}

void UI::priceSum_ui() {
	cout <<"\nSuma preturilor: " << srv.priceSum();
}

void UI::undo_ui() {
	srv.undo();
	cout << "\nUndo success!";
}

void UI::print_menu()
{
	cout << "\n===MENU===\n";
	cout << "1. Adauga\n2. Afiseaza\n3. Modifica\n4. Sterge\n5. Cauta\n6. Filtreaza\n7. Sorteaza\n8. Statistica\n";
	cout << "9. Goleste reteta\n10. Adauga medicament la reteta\n11. Genereaza reteta\n12. Export reteta in fisier\n";
	cout << "13. Afiseaza reteta\n14. Suma preturilor\n15. undo\n0. Exit\n";
}

void UI::showRecipe_ui(){
	vector<Medicament> recipe = srv.getRecipe();
	cout << "Reteta:\n";
	for (const auto& med : recipe) {
		cout << med;
	}
}

void UI::run()
{
	bool final = false;
	while (!final)
	{
		print_menu();
		string cmd;

		cout << "Comanda: "; cin >> cmd;

		if (cmd != "0" && atoi(cmd.c_str()) == 0)
			cmd = "-1";
	
		try {
			switch (atoi(cmd.c_str())) {
			case 1:
				adauga_ui();
				break;
			case 2:
				printAll_ui();
				break;
			case 3:
				modifica_ui();
				break;
			case 4:
				sterge_ui();
				break;
			case 5:
				cauta_ui();
				break;
			case 6:
				filtreaza_ui();
				break;
			case 7:
				sorteaza_ui();
				break;
			case 8:
				stats_ui();
				break;
			case 9:
				clearRecipe_ui();
				break;
			case 10:
				addOnRecipe_ui();
				break;
			case 11:
				generateRecipe_ui();
				break;
			case 12:
				export_ui();
				break;
			case 13:
				showRecipe_ui();
				break;
			case 14:
				priceSum_ui();
				break;
			case 15:
				undo_ui();
				break;
			case 0:
				cout << "Exit...";
				final = true;
				break;
			case -1:
				cout << "\nComanda invalida! Reintroduceti\n";
				break;
			default:
				cout << "\nComanda invalida! Reintroduceti\n";
				break;
			}
		}
		catch (const ValidatorException& ex) {
			cout <<'\n' << ex;
		}
		catch (const RepositoryException& ex) {
			cout << '\n' << ex;
		}
		catch (std::ofstream::failure ex) {
			cout << "FILE ERROR! Retry...\n";
		}
	}
}