#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h> 
#include <iostream>
#include "Tests.h"
#include "UI.h"

int main() {
	{
		Reteta recipe;
		//ProbRepo repo(0.5);
		//FileRepo repo("meds.txt");
		Repository repo;
		Validator val;
		Service srv{ repo, val, recipe};
		UI ui{ srv };

		Tests t;
		t.testAll();
		ui.run();
	}
	_CrtDumpMemoryLeaks();
	return 0;
}