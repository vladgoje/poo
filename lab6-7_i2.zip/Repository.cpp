#include "Repository.h"


//=============Repo Exception================
RepositoryException::RepositoryException(const string& msg) {
	this->errors.push_back(msg);
}

ostream& operator<<(ostream& out, const RepositoryException& ex) {
	VectorDinamic<string> msgs = ex.errors;
	IteratorVD<string> it = msgs.begin();
	while (it != msgs.end())
	{
		out << *it <<"\n";
		++it;
	}
	return out;
}

//=============Repo================

void Repository::adauga(const Medicament& med) {
	if (exist(med))
		throw RepositoryException("Medicamentul introdus exista deja!");
	vd.push_back(med);
}

bool Repository::exist(const Medicament& med) noexcept{
	IteratorVD<Medicament> it = vd.begin();
	while (it != vd.end())
	{
		if ((*it).getName() == med.getName())
			return true;
		++it;
	}
	return false;
}

const VectorDinamic<Medicament>& Repository::getAll() const noexcept{
	return this->vd;
}

void Repository::modifica(const int id, const Medicament& med) {
	if (id >= vd.get_len() || id < 0)
		throw RepositoryException("Medicamentul cu id introdus nu exista!");
	
	Medicament t = vd.get_at_pos(id);
	if (t.getName() == med.getName() && t.getProd() == med.getProd() && t.getSubst() == med.getSubst() && t.getPrice() == med.getPrice())
		throw RepositoryException("Medicamentul cu id introdus nu a fost modificat!");
	
	if (exist(med))
		throw RepositoryException("Nu poti modifica medicamentul! Exista deja un medicament cu datele introduse.");
	
	vd.update_at_pos(id, med);
}

void Repository::sterge(const int id) {
	if (id >= vd.get_len())
		throw RepositoryException("Medicamentul cu id introdus nu exista!");
	vd.delete_at_pos(id);
}

const Medicament& Repository::get(const int id) const {
	if(id >= vd.get_len())
		throw RepositoryException("Medicamentul cu id introdus nu exista!");
	return *(vd.SelectPos(id));
}

const Medicament& Repository::search(const string& name) const {
	IteratorVD<Medicament> it = vd.begin();
	while (it != vd.end())
	{
		if ((*it).getName() == name)
			return *it;
		++it;
	}
	throw RepositoryException("Medicamentul cu numele introdus nu exista!");}


