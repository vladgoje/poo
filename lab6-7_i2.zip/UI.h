#pragma once
#include "Service.h"
#include "Medicament.h"

class UI {

private:
	Service& srv;
	/*
	Citeste date de la tastatura si adauga medicament
	arunca exceptie daca: nu e valid, nu se poate salva in repo
	*/
	void adauga_ui();

	/*
	Tipareste o lista de medicamente in consola
	arunca exceptie daca nu exista medicamente introduse
	*/
	void printAll_ui();

	/*
	Citeste date de la tastatura si modifica medicament
	arunca exceptie daca datele introduse nu sunt valide, nu exista medicamentul cu id introdus in repo/  daca nu exista medicamente introduse
	*/
	void modifica_ui();

	/*
	Sterge element cu id introdus
	arunca exceptie daca: nu exista medicament cu id introdus /  daca nu exista medicamente introduse
	*/
	void sterge_ui();

	/*
	Citeste un nume de medicament de la tastatura si afiseaza toate medicamentele cu acel nume
	arunca exceptie daca nu exista medicamente cu numele introdus /  daca nu exista medicamente introduse
	*/
	void cauta_ui();

	/*
	Citeste de la tastatura un tip de filtrare si un filtru si afiseaza toate medicamentele care se potrivesc datelor introduse
	arunca exceptie daca tipul nu e valid / daca filtru nu e valid / daca filtrele sunt valide dar nu a gasit niciun medicament
	*/
	void filtreaza_ui();
	/*
	Citeste de la tastatura un tip de sortare si afiseaza alimentele sortate dupa tipul ales
	arunca exceptie daca tipul de sortare nu e valid / daca nu exista medicamente introduse
	*/
	void sorteaza_ui();

	/*
	Tipareste meniul aplicatiei
	*/
	void print_menu();

	/*statistica lab 6-7*/
	void stats_ui();
	
public:
	UI(Service& srv) noexcept :srv{ srv } {}
	UI(const UI& ot) = delete;
	void run();
};