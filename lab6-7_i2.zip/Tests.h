#pragma once
#include "Service.h"
#include <assert.h>

class Tests {
	//teste domain
	void testGetter();
	void testSetter();
	void testMed();
	void testDomain();

	//teste vector dinamic + iterator
	void testVectorDinamic();
	void testIterator();
	void testVD();

	//teste repo
	void testAdd_rep();
	void testGetAll_rep();
	void testGet_rep();
	void testModifica_rep();
	void testDelete_rep();
	void testCauta_rep();
	void testRepo();

	//teste service
	void testAdd_srv();
	void testGetAll_srv();
	void testGet_srv();
	void testModifica_srv();
	void testDelete_srv();
	void testCauta_srv();
	void testFiltreaza1_srv();
	void testFiltreaza2_srv();
	void testSortare_srv();
	void testStats_srv();
	void testService();

	//teste validator
	void testValideazaMed();
	void testValideazaFiltrare();
	void testValideazaString();
	void testValideazaType();
	void testValideazaID();
	void testValideazaPrice();
	void testValidator();

public:
	void testAll();
};