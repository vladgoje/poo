#pragma once
template <typename TElem>
class VectorDinamic;

template <typename TElem>
class IteratorVD {
private:
	const VectorDinamic<TElem>& vd;
	int poz;
public:

	//constructori
	IteratorVD(const VectorDinamic<TElem>& v) noexcept: vd{ v }, poz{ 0 }{}
	IteratorVD(const VectorDinamic<TElem>& v, int lg) noexcept: vd{ v }, poz{ lg }{}

	//metode
	TElem& element() const noexcept;
	bool valid() const noexcept;
	void next() noexcept;
	int getPoz() const noexcept;

	//operatori
	TElem& operator*() noexcept;
	IteratorVD& operator++() noexcept;
	bool operator!=(const IteratorVD<TElem>& it) const noexcept;
};

template <typename TElem>
TElem& IteratorVD<TElem>::element() const noexcept {
	return this->vd.get_at_pos(this->poz);
}

template <typename TElem>
bool IteratorVD<TElem>::valid() const noexcept {
	return poz < vd.get_len();
}

template <typename TElem>
void IteratorVD<TElem>::next() noexcept{
	poz++;
}

template <typename TElem>
TElem& IteratorVD<TElem>::operator*() noexcept{
	return element();
}

template <typename TElem>
IteratorVD<TElem>& IteratorVD<TElem>::operator++() noexcept {
	next();
	return *this;
}

template <typename TElem>
bool IteratorVD<TElem>::operator!=(const IteratorVD<TElem>& it) const noexcept {
	return poz != it.poz;
}



template <typename TElem>
int IteratorVD<TElem>::getPoz() const noexcept{
	return this->poz;
}



