#pragma once
#include "VectorDinamic.h"
#include "Medicament.h" 

using std::string;
using std::ostream;

class RepositoryException {
	VectorDinamic<string> errors;

public:
	RepositoryException(const string& msg);
	friend ostream& operator<<(ostream& out, const RepositoryException& ex);
};

ostream& operator<<(ostream& out, const RepositoryException& ex);

class Repository {

private:
	VectorDinamic<Medicament> vd;
	bool exist(const Medicament& med) noexcept;

public:
	Repository() noexcept = default;
	Repository(const Repository& ot) noexcept = delete;

	const VectorDinamic<Medicament>& getAll() const noexcept;
	void adauga(const Medicament& med);
	void modifica(const int id, const Medicament& med);
	void sterge(const int id);
	const Medicament& search(const string& name) const;
	const Medicament& get(const int id) const;
};