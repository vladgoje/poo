#pragma once
#include "Repository.h"
#include "Validator.h"

using std::string;

class Service {
private:
	Repository& repo;
	Validator& val;
public:
	Service(Repository& repo, Validator& val) noexcept :repo{ repo }, val{ val } {}
	Service(const Service& ot) = delete;

	void adauga(const string& name, const string& prod, const string& subst, const string& price);
	void modifica(const string& id, const string& name, const string& prod, const string& subst, const string& price);
	const VectorDinamic<Medicament>& getAll() noexcept;
	void sterge(const string& id);
	const Medicament& cauta(const string& name);
	VectorDinamic<Medicament> filtreaza(const string& type, const string& filter1, const string& filter2);
	VectorDinamic<Medicament> sorteaza(const string& type);
	VectorDinamic<Medicament> GeneralSort(bool(*cmp)(const Medicament& m1, const Medicament& m2)) noexcept;

	VectorDinamic<StatsDTO> stats();
};