#pragma once
#include "VectorDinamic.h"
#include <iostream>
#include <string>

using std::string;
using std::ostream;

class ValidatorException {
	VectorDinamic<string> errors;
	friend class Validator;
public:
	ValidatorException(const VectorDinamic<string>& msgs);
	friend ostream& operator<<(ostream& out, const ValidatorException& ex);
};

ostream& operator<<(ostream& out, const ValidatorException& ex);

class Validator {

public:
	void valideazaMed(const Medicament& med) const;
	void valideazaFiltrare(const string& type, const string& filter1, const string& filter2) const;
	void valideazaString(const string& name) const;
	void valideazaType(const string& type) const;
	void valideazaId(const string& id) const;
	void valideazaPrice(const string& id) const;
};