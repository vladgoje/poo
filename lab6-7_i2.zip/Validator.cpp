#include "Validator.h"
#include <float.h>

//================Validator Exception===========
ValidatorException::ValidatorException(const VectorDinamic<string>& msgs) {
	IteratorVD<string> it = msgs.begin();
	while (it != msgs.end())
	{
		this->errors.push_back(*it);
		++it;
	}
}

ostream& operator<<(ostream& out, const ValidatorException& ex) {
	VectorDinamic<string> msgs = ex.errors;
	IteratorVD<string> it = msgs.begin();
	while (it != msgs.end())
	{
		out << *it << "\n";
		++it;
	}
	return out;
}

//================Validator===========

void Validator::valideazaMed(const Medicament& med) const{
	VectorDinamic<string> errors;
	if (med.getName().size() == 0) 
		errors.push_back("Nume nu poate fi vid");
	if (med.getProd().size() == 0)
		errors.push_back("Producator nu poate fi vid");
	if (med.getSubst().size() == 0)
		errors.push_back("Substanta nu poate fi vida");
	if (med.getPrice() <= 0 || med.getPrice() >= INT_MAX)
		errors.push_back("Pret invalid");
	if (errors.get_len())
		throw ValidatorException(errors);
}

void Validator::valideazaFiltrare(const string& type, const string& filter1, const string& filter2) const {
	VectorDinamic<string> errors;
	if (type != "1" && type != "2")
		errors.push_back("Tipul de filtrare nu e valid! Reintroduceti");

	if(type == "2" && (!atof(filter1.c_str()) || !atof(filter2.c_str()) || atof(filter1.c_str()) < 0 || atof(filter2.c_str()) >= INT_MAX || atof(filter1.c_str()) > atof(filter2.c_str() )))
		errors.push_back("Preturile introduse nu sunt valide! Reintroduceti");

	else {
		try
		{ valideazaString(filter1); }
		catch (ValidatorException&){ errors.push_back("Filtrul nu e valid! Reintroduceti"); }
	}

	if (errors.get_len())
		throw ValidatorException(errors);
}

void Validator::valideazaString(const string& filter) const {
	VectorDinamic<string> errors;
	if (filter.size() <= 0)
		errors.push_back("Numele nu e valid! Reintroduceti");
	if (errors.get_len())
		throw ValidatorException(errors);
}

void Validator::valideazaType(const string& type) const {
	VectorDinamic<string> errors;
	if (type != "1" && type != "2" && type != "3")
		errors.push_back("Tipul de sortare nu e valid! Reintroduceti");
	if (errors.get_len())
		throw ValidatorException(errors);
}

void Validator::valideazaId(const string& id) const {
	VectorDinamic<string> errors;
	if ((atoi(id.c_str()) == 0 && id != "0") || atoi(id.c_str()) < 0)
		errors.push_back("Id invalid!");
	if (errors.get_len())
		throw ValidatorException(errors);
}

void Validator::valideazaPrice(const string& price) const {
	VectorDinamic<string> errors;
	if (atof(price.c_str()) == 0 && price != "0" || atof(price.c_str()) < 0)
		errors.push_back("Pret invalid!");
	if (errors.get_len())
		throw ValidatorException(errors);
}