#include "Service.h"
#include <unordered_map> 

void Service::adauga(const string& name, const string& prod, const string& subst, const string& price) {
	val.valideazaPrice(price);
	Medicament med{ name, prod, subst, price };
	val.valideazaMed(med);
	repo.adauga(med);
}

const VectorDinamic<Medicament>& Service::getAll() noexcept{
	return repo.getAll();
}

void Service::modifica(const string& id, const string& name, const string& prod, const string& subst, const string& price) {
	val.valideazaPrice(price);
	val.valideazaId(id);
	Medicament med{ name, prod, subst, price };
	val.valideazaMed(med);
	repo.modifica(atoi(id.c_str()), med);
}

void Service::sterge(const string& id) {
	val.valideazaId(id);
	repo.sterge(atoi(id.c_str()));
}

const Medicament& Service::cauta(const string& name) {
	val.valideazaString(name);
	return repo.search(name);
} 

VectorDinamic<Medicament> Service::filtreaza(const string& type, const string& filter1, const string& filter2){
	val.valideazaFiltrare(type, filter1, filter2);
	if (type == "1") {
		VectorDinamic<Medicament> all = getAll();
		VectorDinamic<Medicament> filtered;
		IteratorVD<Medicament> it = all.begin();
		while (it != all.end()) {
			if ((*it).getSubst() == filter1)
				filtered.push_back(*it);
			++it;
		}
		return filtered;}
	else {
		VectorDinamic<Medicament> all = getAll();
		VectorDinamic<Medicament> filtered;
		IteratorVD<Medicament> it = all.begin();
		while (it != all.end()) {
			if ((*it).getPrice() >= atof(filter1.c_str()) && (*it).getPrice() <= atof(filter2.c_str()))
				filtered.push_back(*it);
			++it;
		}
		return filtered;}
}

VectorDinamic<Medicament> Service::sorteaza(const string& type) {
	val.valideazaType(type);
	if (type == "1")
		return GeneralSort([](const Medicament& m1, const Medicament& m2) noexcept {
		return m1.getName() > m2.getName(); });

	else if (type == "2")
		return GeneralSort([](const Medicament& m1, const Medicament& m2) noexcept {
		return m1.getProd() > m2.getProd(); });
	else
		return GeneralSort([](const Medicament& m1, const Medicament& m2)noexcept {
		if (m1.getSubst() == m2.getSubst())
			return m1.getPrice() > m2.getPrice();
		return m1.getSubst() > m2.getSubst();
			});}

VectorDinamic<Medicament> Service::GeneralSort(bool(*cmpMaiMare)(const Medicament& m1, const Medicament& m2)) noexcept{
	VectorDinamic<Medicament> all = getAll();
	for (IteratorVD<Medicament> i = all.begin(); i.getPoz() < all.get_len() - 1; ++i)
		for (IteratorVD<Medicament> j = all.SelectPos(i.getPoz() + 1); j.getPoz() < all.get_len(); ++j) 
			if (cmpMaiMare(*i, *j))
			{
				Medicament aux = std::move(*i);
				*i = *j;
				*j = aux;
			}
	return all;
}

VectorDinamic<StatsDTO> Service::stats() {
	
	std::unordered_map<string, int> stats;
	VectorDinamic<Medicament> all = getAll();
	IteratorVD<Medicament> it = all.begin();
	
	while (it != all.end()) {
		stats[(*it).getProd()]++;
		++it;
	}

	VectorDinamic<StatsDTO> v_stats;
	for (auto s : stats)
		v_stats.push_back(StatsDTO(s.first, ( (float) s.second / (float) all.get_len())*100));

	return v_stats;
}