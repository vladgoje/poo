#include "Ui.h"
#include "Validator.h"
#include <iostream>

using std::cout;
using std::cin;
using std::string;

void UI::adauga_ui() {
	string name, prod, subst, price;
	cout << "\nNume: "; cin >> name; cout << "Producator: "; cin >> prod; cout << "Substanta activa: "; cin >> subst; cout << "Pret: "; cin >> price;
	srv.adauga(name, prod, subst, price);
	cout << "\nMedicament adaugat cu succes!\n";
}

void UI::printAll_ui() {
	const VectorDinamic<Medicament> all = srv.getAll();
	IteratorVD<Medicament> it = all.begin();
	cout << "\nLista Medicamente:\n";
	while (it != all.end())
	{
		cout <<"(ID: "<<it.getPoz()<<") => " << "Nume: " << (*it).getName() << ", Producator: " << (*it).getProd() << ", Substanta activa: " << (*it).getSubst() << ", Pret: " << (*it).getPrice() << '\n';
		++it;
	}
}

void UI::modifica_ui() {
	printAll_ui();
	string name, prod, subst, price, id;
	cout << "\nID medicament: "; cin >> id;
	cout << "Nume: "; cin >> name; cout << "Producator: "; cin >> prod; cout << "Substanta activa: "; cin >> subst; cout << "Pret: "; cin >> price;
	srv.modifica(id, name, prod, subst, price);
	cout << "\nMedicament modificat cu success!\n";
}

void UI::sterge_ui() {
	string id;
	printAll_ui();
	cout << "\nID medicament: "; cin >> id;
	srv.sterge(id);
	cout << "\nMedicament (ID: " << id << ") a fost sters cu succes!\n";
}

void UI::cauta_ui() {
	string name;
	cout << "\nNume medicament: "; cin >> name;
	const Medicament& med = srv.cauta(name);
	cout << "Nume: " << med.getName() << ", Producator: " << med.getProd() << ", Substanta activa: " << med.getSubst() << ", Pret: " << med.getPrice() << '\n';
}

void UI::filtreaza_ui() {
	string type, filter1, filter2;
	cout << "\n1. Filtreaza dupa substanta activa\n";
	cout << "2. Filtreaza dupa pret\n";
	cout << "Tip filtrare: "; cin >> type;

	if (type == "2") {
		cout << "Pret minim: "; cin >> filter1;
		cout << "Pret maxim: "; cin >> filter2;
	}
	else
	{
		cout << "Filtru: "; cin >> filter1;
	}

	VectorDinamic<Medicament> filtered = srv.filtreaza(type, filter1, filter2);

	if (filtered.get_len() == 0) {
		cout << "\nNu exista medicamente pentru filtrul introdus!\n";
		return;
	}

	IteratorVD<Medicament> it = filtered.begin();
	cout << "\nMedicamente filtrate:\n";
	while (it != filtered.end())
	{
		cout << "Nume: " << (*it).getName() << ", Producator: " << (*it).getProd() << ", Substanta activa: " << (*it).getSubst() << ", Pret: " << (*it).getPrice() << '\n';
		++it;
	}
}

void UI::sorteaza_ui() {
	string type;
	cout << "\n1. Sorteaza dupa nume\n";
	cout << "2. Sorteaza dupa producator\n";
	cout << "3. Sorteaza dupa substanta activa + pret\n";
	cout << "Tip sortare: "; cin >> type;

	VectorDinamic<Medicament> sorted = srv.sorteaza(type);
	cout << "\nMedicamente sortate:\n";
	IteratorVD<Medicament> it = sorted.begin();
	while (it != sorted.end())
	{
		cout << "Nume: " << (*it).getName() << ", Producator: " << (*it).getProd() << ", Substanta activa: " << (*it).getSubst() << ", Pret: " << (*it).getPrice() << '\n';
		++it;
	}
}

void UI::stats_ui() {

	VectorDinamic<StatsDTO> stats = srv.stats();
	IteratorVD<StatsDTO> it = stats.begin();
	cout << "Stats:\n";
	while (it != stats.end())
	{
		cout << (*it).getTip() << " -> " << (*it).getNr()<<" %\n";
		++it;
	}
}


void UI::print_menu()
{
	cout << "\n===MENU===\n";
	cout << "1. Adauga\n2. Afiseaza\n3. Modifica\n4. Sterge\n5. Cauta\n6. Filtreaza\n7. Sorteaza\n0. Exit\n";
}

void UI::run()
{
	bool final = false;
	while (!final)
	{
		print_menu();
		string cmd;

		cout << "Comanda: "; cin >> cmd;

		if (cmd != "0" && atoi(cmd.c_str()) == 0)
			cmd = "-1";
	
		try {
			switch (atoi(cmd.c_str())) {
			case 1:
				adauga_ui();
				break;
			case 2:
				printAll_ui();
				break;
			case 3:
				modifica_ui();
				break;
			case 4:
				sterge_ui();
				break;
			case 5:
				cauta_ui();
				break;
			case 6:
				filtreaza_ui();
				break;
			case 7:
				sorteaza_ui();
				break;
			case 8:
				stats_ui();
				break;
			case 0:
				cout << "Exit...";
				final = true;
				break;
			case -1:
				cout << "\nComanda invalida! Reintroduceti\n";
				break;
			default:
				cout << "\nComanda invalida! Reintroduceti\n";
				break;
			}
		}
		catch (const ValidatorException& ex) {
			cout <<'\n' << ex;
		}
		catch (const RepositoryException& ex) {
			cout << '\n' << ex;
		}
	}
}