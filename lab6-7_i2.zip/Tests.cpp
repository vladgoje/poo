#include "Tests.h"
#include <fstream>
std::ofstream fout("tests.txt");

// ============= TESTE DOMAIN =====================
void Tests::testGetter() {
	Medicament b{ "nume", "prod", "subst", "12.3" };
	assert(b.getName() == "nume");
	assert(b.getProd() == "prod");
	assert(b.getSubst() == "subst");
	assert(b.getPrice() == 12.3);
}

void Tests::testSetter() {
	Medicament b{ "nume", "prod", "subst", "12.3" };

	b.setName("mod1");
	b.setProd("mod2");
	b.setSubst("mod3");
	b.setPrice(45.6);

	assert(b.getName() == "mod1");
	assert(b.getProd() == "mod2");
	assert(b.getSubst() == "mod3");
	assert(b.getPrice() == 45.6);
}

void Tests::testMed() {
	Medicament b{ "nume", "prod", "subst", "12.3" };
	assert(b.getName() == "nume");
	assert(b.getProd() == "prod");
	assert(b.getSubst() == "subst");
	assert(b.getPrice() == 12.3);
	Medicament c{ "nume", "x", "x", "12.3" };
	assert(b == c);
	assert((b != c) == false);
	Medicament d = c;

	assert(c.getName() == d.getName());
	assert(c.getProd() == d.getProd());
	assert(c.getSubst() == d.getSubst());
	assert(c.getPrice() == d.getPrice());
}

void Tests::testDomain() {
	testGetter();
	testSetter();
	testMed();
}

// ========== TESTE VECTOR DINAMIC ==============
void Tests::testVectorDinamic() {
	VectorDinamic<int> vd;
	for (int i = 0; i < 10; i++)
		vd.push_back(i);

	VectorDinamic<int> vd_copy(vd);
	assert(vd_copy.get_len() == vd.get_len());

	VectorDinamic<int> vd_copy2 = vd;
	assert(vd_copy2.get_len() == vd.get_len());

	assert(vd.get_at_pos(7) == 7);
	assert(vd.search(7) == 7);
	assert(vd.get_len() == 10);

	assert(vd.search(72) == -1);

	VectorDinamic<int> all = vd.getAll();
	assert(all.get_at_pos(7) == 7);
	assert(all.search(7) == 7);
	assert(all.get_len() == 10);
	
	vd.update_at_pos(5, -5);
	assert(vd.get_at_pos(5) == -5);

	vd.delete_at_pos(5);
	assert(vd.get_at_pos(5) == 6);
	assert(vd.get_len() == 9);
}

void Tests::testIterator() {
	VectorDinamic<int> vd;
	for (int i = 0; i < 10; i++)
		vd.push_back(i);

	auto it = vd.begin();
	while (it != vd.end()) {
		assert(*it == it.getPoz());
		++it;
	}

	auto it2 = vd.end();
	assert(it2.getPoz() == 10);

	auto it3 = vd.SelectPos(7);
	assert(*it3 == 7);
}

void Tests::testVD() {
	testVectorDinamic();
	testIterator();
}

// ================ TESTE REPO =======================
void Tests::testAdd_rep() {
	Repository repo;
	assert(repo.getAll().get_len() == 0);
	Medicament a{ "nume", "prod", "subst", "12.3" };
	repo.adauga(a);

	VectorDinamic<Medicament> all = repo.getAll();
	IteratorVD<Medicament> it = all.begin();
	assert(all.get_len() == 1);
	assert((*it).getName() == "nume");
	assert((*it).getSubst() == "subst");
	assert((*it).getProd() == "prod");
	assert((*it).getPrice() == 12.3);

	try
	{repo.adauga(Medicament{ "nume", "x", "x", "12.3" }); assert(false);	}
	catch (const RepositoryException& ex) { assert(true); fout << ex; }
}

void Tests::testGetAll_rep() {
	Repository repo;
	repo.adauga(Medicament{ "nume1", "prod1", "subst1", "12.3" });
	repo.adauga(Medicament{ "nume2", "prod2", "subst2", "12.3" });
	repo.adauga(Medicament{ "nume3", "prod3", "subst3", "12.3" });
	VectorDinamic<Medicament> all = repo.getAll();
	IteratorVD<Medicament> it = all.begin();
	assert(all.get_len() == 3);
	assert((*it).getName() == "nume1");
	++it;
	assert((*it).getProd() == "prod2");
	++it;
	assert((*it).getSubst() == "subst3");
	assert((*it).getPrice() == 12.3);
}

void Tests::testGet_rep() {
	Repository repo;
	repo.adauga(Medicament{ "nume1", "prod1", "subst1", "12.3" });
	const Medicament& med = repo.get(0);
	assert(med.getName() == "nume1");
	try
	{const Medicament& no_med = repo.get(7); assert(false); no_med.getName();}
	catch (RepositoryException&) { assert(true); }
}

void Tests::testModifica_rep() {
	Repository repo;
	repo.adauga(Medicament{ "nume", "prod", "subst", "12.3" });
	repo.modifica(0, Medicament{ "mod", "mod", "mod", "45.6" });
	VectorDinamic<Medicament> all = repo.getAll(); 
	Medicament test = all.get_at_pos(0);
	assert(test.getName() == "mod");
	assert(test.getProd() == "mod");
	assert(test.getSubst() == "mod");
	assert(test.getPrice() == 45.6);
	try
	{repo.modifica(1, Medicament{"a", "a", "a", "1.2" }); assert(false);}
	catch (RepositoryException&) { assert(true); }
	try
	{repo.modifica(0, Medicament{"mod", "mod", "mod", "45.6"}); assert(false);}
	catch (RepositoryException&) { assert(true); }
	try
	{repo.modifica(0, Medicament{ "mod", "a", "a", "1.2" }); assert(false);}
	catch (RepositoryException&) { assert(true); }
}

void Tests::testDelete_rep() {
	Repository repo;
	assert(repo.getAll().get_len() == 0);
	repo.adauga(Medicament{ "nume1", "prod1", "subst1", "12.3" });
	repo.adauga(Medicament{ "nume2", "prod2", "subst2", "12.3" });
	VectorDinamic<Medicament> all = repo.getAll();
	assert(all.get_len() == 2);
	repo.sterge(0);
	all = repo.getAll();
	assert(all.get_len() == 1);
	repo.sterge(0);
	all = repo.getAll();
	assert(all.get_len() == 0);

	try
	{repo.sterge(7); assert(false);}
	catch (RepositoryException&) { assert(true); }
}

void Tests::testCauta_rep() {
	Repository repo;
	repo.adauga(Medicament{ "nume", "prod1", "subst1", "12.3" });
	repo.adauga(Medicament{ "x", "prod1", "subst1", "12.3" });

	const Medicament& med = repo.search("x");
	assert(med.getName() == "x");
	assert(med.getProd() == "prod1");
	assert(med.getSubst() == "subst1");
	assert(med.getPrice() == 12.3);

	try
	{const Medicament& no_med = repo.search("y"); assert(false); no_med.getName();}
	catch (RepositoryException&) { assert(true); }
}

void Tests::testRepo() {
	testAdd_rep();
	testGetAll_rep();
	testGet_rep();
	testModifica_rep();
	testDelete_rep();
	testCauta_rep();
}

// =================== TESTE SERVICE ======================
void Tests::testAdd_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };

	assert(srv.getAll().get_len() == 0);
	srv.adauga("nume", "prod", "subst", "12.3");
	VectorDinamic<Medicament> all = srv.getAll();
	IteratorVD<Medicament> it = all.begin();
	assert(all.get_len() == 1);
	assert((*it).getName() == "nume");
	assert((*it).getSubst() == "subst");
	assert((*it).getProd() == "prod");
	assert((*it).getPrice() == 12.3);

	try
	{ srv.adauga("", "", "", "-4"); assert(false); }
	catch (const ValidatorException& ex) { assert(true);  fout << ex; }
	try
	{ srv.adauga("x", "", "y", "123.3"); assert(false); }
	catch (ValidatorException& ) { assert(true); }
}

void Tests::testGetAll_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume1", "prod1", "subst1", "12.3");
	srv.adauga("nume2", "prod2", "subst2", "12.3");
	srv.adauga("nume3", "prod3", "subst3", "12.3");

	VectorDinamic<Medicament> all = srv.getAll();
	IteratorVD<Medicament> it = all.begin();
	assert(all.get_len() == 3);
	assert((*it).getName() == "nume1");
	++it;
	assert((*it).getProd() == "prod2");
	++it;
	assert((*it).getSubst() == "subst3");
	assert((*it).getPrice() == 12.3);
}

void Tests::testGet_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume1", "prod1", "subst1", "12.3");
	const Medicament& med = repo.get(0);
	assert(med.getName() == "nume1");
}

void Tests::testModifica_srv(){
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume", "prod", "subst", "12.3");
	srv.modifica("0", "mod", "mod", "mod", "45.6");

	assert((*srv.getAll().begin()).getName() == "mod");
	assert((*srv.getAll().begin()).getProd() == "mod");
	assert((*srv.getAll().begin()).getSubst() == "mod");
	assert((*srv.getAll().begin()).getPrice() == 45.6);

	try
	{ srv.modifica("0", "", "", "", "-1"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{ srv.modifica("a", "a", "a", "a", "1.2"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testDelete_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	assert(srv.getAll().get_len() == 0);
	srv.adauga("nume1", "prod1", "subst1", "12.3");
	srv.adauga("nume2", "prod2", "subst2", "12.3");
	assert(srv.getAll().get_len() == 2);
	srv.sterge("0");
	assert(srv.getAll().get_len() == 1);
	srv.sterge("0");
	assert(srv.getAll().get_len() == 0);
	assert(srv.getAll().get_len() == 0);
}

void Tests::testCauta_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume", "prod1", "subst1", "12.3");
	srv.adauga("x", "prod1", "subst1", "12.3");

	const Medicament& med = srv.cauta("x");
	assert(med.getName() == "x");
	assert(med.getProd() == "prod1");
	assert(med.getSubst() == "subst1");
	assert(med.getPrice() == 12.3);
}

void Tests::testFiltreaza1_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume1", "prod1", "x", "12.3");
	srv.adauga("nume2", "prod2", "subst2", "12.3");
	srv.adauga("nume3", "prod3", "x", "45.6");

	VectorDinamic<Medicament> all = srv.filtreaza("1", "x", "");
	assert(all.get_len() == 2);
	IteratorVD<Medicament> it = all.begin();
	assert((*it).getName() == "nume1");
	assert((*it).getSubst() == "x");
	assert((*it).getPrice() == 12.3);
	++it;
	assert((*it).getName() == "nume3");
	assert((*it).getSubst() == "x");
	assert((*it).getPrice() == 45.6);
	try
	{ VectorDinamic<Medicament> nul_vect = srv.filtreaza("1", "", ""); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{ VectorDinamic<Medicament> nul_vect = srv.filtreaza("7", "a", "b"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testFiltreaza2_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("nume1", "prod1", "subst1", "1.2");
	srv.adauga("nume2", "prod2", "subst2", "3.4");
	srv.adauga("nume3", "prod3", "subst3", "5.6");

	VectorDinamic<Medicament> all = srv.filtreaza("2", "1.2", "3.5");
	assert(all.get_len() == 2);
	IteratorVD<Medicament> it = all.begin();
	assert((*it).getName() == "nume1");
	assert((*it).getPrice() == 1.2);

	try
	{ VectorDinamic<Medicament> nul_vect = srv.filtreaza("2", "abc", "def"); assert(false); }
	catch (ValidatorException&) { assert(true); }	
}

void Tests::testSortare_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("a", "c", "b", "3.4");
	srv.adauga("b", "b", "a", "1.2");
	srv.adauga("c", "a", "c", "1.2");
	srv.adauga("x", "x", "a", "4.5");
	 
	VectorDinamic<Medicament> sort1 = srv.sorteaza("1");
	IteratorVD<Medicament> it = sort1.begin();

	assert((*it).getName() == "a");
	assert((*it).getSubst() == "b");
	assert((*it).getPrice() == 3.4);
	++it;
	assert((*it).getName() == "b");
	assert((*it).getSubst() == "a");
	assert((*it).getPrice() == 1.2);
	
	VectorDinamic<Medicament> sort2 = srv.sorteaza("2");
	IteratorVD<Medicament> it2 = sort2.begin();
	assert((*it2).getName() == "c");
	assert((*it2).getProd() == "a");
	assert((*it2).getPrice() == 1.2);
	++it2;
	assert((*it2).getName() == "b");
	assert((*it2).getProd() == "b");
	assert((*it2).getPrice() == 1.2);

	VectorDinamic<Medicament> sort3 = srv.sorteaza("3");
	IteratorVD<Medicament> it3 = sort3.begin();
	assert((*it3).getSubst() == "a");
	assert((*it3).getPrice() == 1.2);
	++it3;
	assert((*it3).getSubst() == "a");
	assert((*it3).getPrice() == 4.5);
	
	try 
	{ VectorDinamic<Medicament> no_sort = srv.sorteaza("7"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testStats_srv() {
	Repository repo; Validator val;  Service srv{ repo, val };
	srv.adauga("a", "x", "b", "3.4");
	srv.adauga("b", "x", "a", "1.2");
	srv.adauga("c", "x", "c", "1.2");
	srv.adauga("d", "y", "a", "4.5");
	srv.adauga("e", "y", "a", "4.5");
	srv.adauga("f", "z", "a", "4.5");

	VectorDinamic<StatsDTO> stats = srv.stats();
	int sum_x{ 0 }, sum_y{ 0 }, sum_z{ 0 };
	assert(stats.get_len() == 3);
	IteratorVD<StatsDTO> it = stats.begin();
	while (it != stats.end())
	{
		if ((*it).getTip() == "x")
		{
			sum_x++;
			assert((*it).getNr() == 50.0);
		}
		if ((*it).getTip() == "y")
			sum_y++;
		if ((*it).getTip() == "z")
			sum_z++;
		++it;
	}
	assert(sum_x == 1);
	assert(sum_y == 1);
	assert(sum_z == 1);
}

void Tests::testService() {
	testAdd_srv();
	testGetAll_srv();
	testGet_srv();
	testModifica_srv();
	testDelete_srv();
	testCauta_srv();
	testFiltreaza1_srv();
	testFiltreaza2_srv();
	testSortare_srv();
	testStats_srv();
}


// ========================TESTE VALIDATOR ========================
void Tests::testValideazaMed() {
	Validator val;
	val.valideazaMed(Medicament{ "a","b","c","12.34" });
	assert(true);
	try
	{val.valideazaMed(Medicament{ "","","","-4.2" }); assert(false);}
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaMed(Medicament{ "a","","c","-1.5" }); assert(false);}
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValideazaFiltrare() {
	Validator val;
	val.valideazaFiltrare("1", "abc", "");
	assert(true);

	val.valideazaFiltrare("2", "3", "14");
	assert(true);

	try
	{val.valideazaFiltrare ("1", "", ""); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaFiltrare("2", "abc", "abc"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaFiltrare("2", "-1", "999"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaFiltrare("2", "1", "-999"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaFiltrare("2", "7", "6"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaFiltrare("3", "a", "a"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValideazaString() {
	Validator val;
	val.valideazaString("abc"); assert(true);
	try
	{val.valideazaString(""); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValideazaType() {
	Validator val;
	val.valideazaType("1"); assert(true);
	val.valideazaType("2"); assert(true);
	val.valideazaType("3"); assert(true);
	try
	{val.valideazaType(""); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaType("7"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValideazaID() {
	Validator val;
	val.valideazaId("7"); assert(true);
	val.valideazaId("0"); assert(true);
	try
	{val.valideazaId("a"); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaId(""); assert(false); }
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaId("-1"); assert(false); }
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValideazaPrice() {
	Validator val;
	val.valideazaPrice("7"); assert(true);
	val.valideazaPrice("0"); assert(true);
	try
	{val.valideazaPrice("a"); assert(false);}
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaPrice(""); assert(false);}
	catch (ValidatorException&) { assert(true); }
	try
	{val.valideazaPrice("-1"); assert(false);}
	catch (ValidatorException&) { assert(true); }
}

void Tests::testValidator() {
	testValideazaMed();
	testValideazaFiltrare();
	testValideazaString();
	testValideazaType();
	testValideazaID();
	testValideazaPrice();
}

// ============= all ========================
void Tests::testAll(){
	testService();
	testRepo();
	testVD();
	testDomain();
	testValidator();
	std::cout << "teste trecute\n";
}