#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h> 
#include <iostream>
#include "Tests.h"
#include "UI.h"

int main() {
	{
		Repository repo;
		Validator val;
		Service srv{ repo, val };
		UI ui{ srv };

		Tests t;
		t.testAll();
		ui.run();
	}
	_CrtDumpMemoryLeaks();
	return 0;
}