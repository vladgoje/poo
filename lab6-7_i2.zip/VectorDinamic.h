#pragma once
#include "Medicament.h"
#include "IteratorVD.h"

template <typename TElem>
class VectorDinamic{

	friend class IteratorVD<TElem>;

private:
	int cap;
	int len;
	std::unique_ptr<TElem[]> elems;
	
public:
	VectorDinamic() throw();
	VectorDinamic(const VectorDinamic<TElem>& vd) throw();
	VectorDinamic(VectorDinamic<TElem>&& vd) = default;
	VectorDinamic& operator=(const VectorDinamic<TElem>& vd) throw();
	VectorDinamic& operator=(VectorDinamic<TElem>&& vd) = default;
	
	//(C)reate
	void push_back(const TElem& elem);
	void verify_capacity();
	//void insert_on_pos(const TElem& elem , int pos);

	//(r)ead
	TElem& get_at_pos(int pos) const noexcept;
	int search(const TElem& elem);
	const int get_len() const noexcept;
	VectorDinamic<TElem> getAll() const;

	//(u)pdate
	void update_at_pos(const int pos, const TElem& elem) throw();

	//(d)elete
	void delete_at_pos(int pos) noexcept;
	//void delete_all();

	IteratorVD<TElem> begin() const noexcept;
	IteratorVD<TElem> end() const noexcept;
	IteratorVD<TElem> SelectPos(int pos) const noexcept;

	~VectorDinamic() {};
};

//implicit constructor
template <typename TElem>
VectorDinamic<TElem>::VectorDinamic() throw()
{
	this->len = 0;
	this->cap = 2;
	this->elems = std::make_unique<TElem[]>(this->cap);
}
  
//copy constructor
template <typename TElem>
VectorDinamic<TElem>::VectorDinamic(const VectorDinamic<TElem>& vd) throw()
{	
	this->len = vd.len;
	this->cap = vd.cap;
	this->elems = std::make_unique<TElem[]>(this->cap);
	for (int i = 0; i < this->len && i < this->cap; i++)
		this->update_at_pos(i, vd.get_at_pos(i));
}

template <typename TElem>
void VectorDinamic<TElem>::push_back(const TElem& elem) {
	verify_capacity();
	this->elems[this->len] = elem;
	this->len++;
}

template <typename TElem>
const int VectorDinamic<TElem>::get_len() const noexcept {
	const int _len = this->len;
	return _len;
}

template <typename TElem>
void VectorDinamic<TElem>::verify_capacity() {
	if (this->len == this->cap)
	{
		this->cap *= 2;
		std::unique_ptr<TElem[]> nElems = std::make_unique<TElem[]>(this->cap);

		//copiem elementele vechi
		for (int i = 0; i < this->len; i++)
			nElems[i] = this->get_at_pos(i);

		//actualizam pointerul spre vectorul de elemente
		this->elems = std::move(nElems);
	}
}

template <typename TElem>
int VectorDinamic<TElem>::search(const TElem& elem) {
	IteratorVD<TElem> it = begin();
	while (it != end())
	{
		if ((*it) == elem)
			return it.getPoz();
		++it;
	}
	return -1;
}

template <typename TElem>
void VectorDinamic<TElem>::update_at_pos(const int pos, const TElem& elem) throw() {
	this->elems[pos] = elem;
}

template <typename TElem>
void VectorDinamic<TElem>::delete_at_pos(const int pos) noexcept {
	for (int i = pos; i < this->len - 1; i++)
		this->update_at_pos(i, this->get_at_pos(i + 1));
	this->len--;
	this->cap--;
}

template <typename TElem>
IteratorVD<TElem> VectorDinamic<TElem>::begin() const noexcept{
	return IteratorVD<TElem>(*this);
}

template <typename TElem>
IteratorVD<TElem> VectorDinamic<TElem>::end() const noexcept{
	return IteratorVD<TElem>(*this, len);
}

template <typename TElem>
IteratorVD<TElem> VectorDinamic<TElem>::SelectPos(int pos) const noexcept{
	return IteratorVD<TElem>(*this, pos);
}

template <typename TElem>
VectorDinamic<TElem> VectorDinamic<TElem>::getAll() const {
	return *this;
}

template <typename TElem>
TElem& VectorDinamic<TElem>::get_at_pos(int pos) const noexcept{
	return elems[pos];
}

template <typename TElem>
VectorDinamic<TElem>& VectorDinamic<TElem>::operator=(const VectorDinamic<TElem>& vd) throw() {
	this->len = vd.len;
	this->cap = vd.cap;
	this->elems = std::make_unique<TElem[]>(this->cap);
	for (int i = 0; i < this->len && i < this->cap; i++)
		this->elems[i] = std::move(vd.elems[i]);
	return *this;
}