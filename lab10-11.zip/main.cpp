#include <QtWidgets/QApplication>
#include <fstream>
#include "GUI.h"
#include "UI.h"
#include "Tests.h"
QT_CHARTS_USE_NAMESPACE
int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	Reteta recipe;
	//Repository repo;
	//ProbRepo repo{ 0.5 };
	FileRepo repo{ "meds.txt" };
	Validator val;
	Service srv{ repo, val, recipe };
	GUI gui{ srv };
	//UI ui{ srv };

	Tests t;
	t.testAll();
	//ui.run();

	gui.show();
	return a.exec();
}
