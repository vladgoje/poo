#include "lab_1011.h"

lab_1011::lab_1011(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
