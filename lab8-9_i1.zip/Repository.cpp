#include "Repository.h"
#include <algorithm>

//=============Repo Exception================
RepositoryException::RepositoryException(const string& msg) {
	this->errors.push_back(msg);
}

ostream& operator<<(ostream& out, const RepositoryException& ex) {
	vector<string> msgs = ex.errors;
	for (const auto& msg : msgs) {
		out << msg << '\n';
	}
	return out;
}

//=============Repo================
void Repository::adauga(const Medicament& med) {
	if (exist(med.getName()))
		throw RepositoryException("Medicamentul introdus exista deja!");
	med_map[med.getName()] = med;
}


bool Repository::exist(const string& name) const{
	if (this->med_map.find(name) == med_map.end()){
		return false;
	}
	return true;
}


vector<Medicament> Repository::getAll() const noexcept{
	vector<Medicament> meds;
	std::transform(med_map.begin(), med_map.end(), std::back_inserter(meds), [](std::pair<string, Medicament> p) {
		return p.second;
		});
	return meds;
}


void Repository::modifica(const string& id, const Medicament& med) {
	if(!exist(id))
		throw RepositoryException("Medicamentul cu numele introdus nu exista!");

	const auto& it = med_map.find(id);
	if (it != med_map.end())
		it->second = med;
}


void Repository::sterge(const string& name) {
	if(!exist(name))
		throw RepositoryException("Medicamentul cu numele introdus nu exista!");
	med_map.erase(name);
}


const Medicament Repository::get(const string& name) {
	if(!exist(name))
		throw RepositoryException("Medicamentul cu numele introdus nu exista!");
	return med_map[name];
}


const Medicament Repository::search(const string& name){
	if(!exist(name))
		throw RepositoryException("Medicamentul cu numele introdus nu exista!");
	return med_map[name];
}


const Reteta& Repository::getRecipe() const noexcept {
	return this->recipe;
}


int Repository::getRecipeSize() const noexcept {
	return this->recipe.getSize();
}


void Repository::clearRecipe() {
	if (this->recipe.getSize() == 0)
		throw(RepositoryException("Reteta este deja goala!"));
	this->recipe.clear();
}


void Repository::addOnRecipe(const Medicament& med) {
	for (const auto& _med : this->recipe.meds)
		if (_med.getName() == med.getName())
			throw(RepositoryException("Medicamentul exista deja pe reteta!"));
	this->recipe.add(med);
}


int Repository::generateReceipe(const Medicament& med) noexcept{
	for (const auto& _med : this->recipe.meds)
		if (_med.getName() == med.getName())
			return 0;
	this->recipe.add(med);
	return 1;
}