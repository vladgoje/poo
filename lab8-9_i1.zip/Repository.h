#pragma once
#include "Domain.h" 
#include <vector>
#include <unordered_map>
using std::string;
using std::ostream;
using std::vector;
using std::unordered_map;

class RepositoryException {
	vector<string> errors;
public:
	RepositoryException(const string& msg);
	friend ostream& operator<<(ostream& out, const RepositoryException& ex);
};

ostream& operator<<(ostream& out, const RepositoryException& ex);

class Repository {

private:
	unordered_map<string, Medicament> med_map;
	Reteta recipe;

	bool exist(const string& name) const;

public:
	Repository() = default;
	Repository(const Repository& ot) = delete;

	vector<Medicament> getAll() const noexcept;
	void adauga(const Medicament& med);
	void modifica(const string& id, const Medicament& med);
	void sterge(const string& name);
	const Medicament search(const string& name);
	const Medicament get(const string& name);

	const Reteta& getRecipe() const noexcept;
	void clearRecipe();
	void addOnRecipe(const Medicament& med);
	int generateReceipe(const Medicament& med) noexcept;
	int getRecipeSize() const noexcept;
};