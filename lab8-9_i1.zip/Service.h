#pragma once
#include "Repository.h"
#include "Validator.h"

using std::string;
using std::vector;

class Service {
private:
	Repository& repo;
	Validator& val;
public:
	Service(Repository& repo, Validator& val) noexcept :repo{ repo }, val{ val } {}
	Service(const Service& ot) = delete;

	void adauga(const string& name, const string& prod, const string& subst, const string& price);
	void modifica(const string& id, const string& name, const string& prod, const string& subst, const string& price);
	const vector<Medicament> getAll() noexcept;
	void sterge(const string& id);
	const Medicament cauta(const string& name);
	vector<Medicament> filtreaza(const string& type, const string& filter1, const string& filter2);
	vector<Medicament> filtreaza_subst(const string& subst);
	vector<Medicament> filtreaza_pret(const double pret1, const double filter2);

	vector<Medicament> sorteaza(const string& type);
	vector<StatsDTO> stats();

	const Reteta& getRecipe() const noexcept;
	int getRecipeSize() const noexcept;
	void clearRecipe();
	void addOnRecipe(const string& name);
	void generateRecipe(const string& nr);
	void exportRecipe(const string& fname);
	string randomString();
	string randomPrice();
	double priceSum();
};